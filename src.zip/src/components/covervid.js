// import React, { Component } from 'react';
// import Cover from 'react-video-cover';


// const style = {
//     width: '100vw',
//     height: '100vh',
//     position: 'fixed',
//     top: 0,
//     left: 0,
//     zIndex: -1,
//   };

//   export default class Covervid extends Component {
//     state = {
//         resizeNotifier: () => {},
//       }
    

//     render() 
//         {const videoOptions = {
//         src: '../Boat.mp4',
//         autoPlay: true,
//         muted: true,
//         loop: true,
//       };

//       return (
//         <LandingPage>
//           <div style={style} >
//             <Cover
//               videoOptions={videoOptions}
//               remeasureOnWindowResize
//               getResizeNotifier={resizeNotifier => {
//                 this.setState({
//                   resizeNotifier,
//                 });
//               }}
//             />
//           </div>
//         </LandingPage>
//       );
//     }
//   }
          
    
