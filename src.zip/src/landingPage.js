
import React, {Component} from 'react';

class LandingPage extends Component {
    constructor (props) {
        super(props);

        this.state = {
            videoURL: "https://static.videezy.com/system/resources/previews/000/020/722/original/P1033770.mp4"
        }
    }

    render () {
        return (
            

           
            <video id="background-video" loop autoPlay>
                
        
                <source src={this.state.videoURL} type="video/mp4" />
                <source src={this.state.videoURL} type="video/ogg" />
                <source src={this.state.videoURL} type="video/webm" />
                Your browser does not support the video tag.
                
            </video>
            

            
        )
    }
};

export default LandingPage;